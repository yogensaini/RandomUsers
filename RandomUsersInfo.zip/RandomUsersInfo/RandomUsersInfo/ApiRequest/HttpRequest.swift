//
//  HttpRequest.swift
//  UserInfomation
//
//  Created by Yogender Saini on 15/12/22.
//


import UIKit

class HttpRequest: NSObject {
    
    func apiRequest(complitionSucc : @escaping(_ result : [UserDataModel]) -> Void, complitionFail : @escaping(_ resultFail : String) -> Void) {
                
        var request = URLRequest(url: URL(string: "https://randomuser.me/api/?results=50")!)
        
        request.httpMethod = "GET"
        request.addValue("application/json", forHTTPHeaderField: "content-type")
        
        URLSession.shared.dataTask(with: request) { respData, httpResponce, error in
            
            if error == nil && respData != nil {
                            
                let decoder = JSONDecoder()
                do {
                    let result = try decoder.decode(userResp.self, from: respData!)
                    complitionSucc(result.results)
                } catch let err {
                    debugPrint(err)
                    complitionFail(err.localizedDescription)
                }
            }
            
        }.resume()
        
    }

}

