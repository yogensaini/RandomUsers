//
//  TbCellUserInfo.swift
//  RandomUsersInfo
//
//  Created by Yogender Saini on 16/01/23.
//

import UIKit
import SDWebImage

class TbCellUserInfo: UITableViewCell {

    @IBOutlet weak var lblName : UILabel!
    @IBOutlet weak var img : UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func setData(pet : UserDataModel) {
        self.lblName.text = pet.getFullName()
        self.img.sd_setImage(with: URL(string: pet.picture.large), placeholderImage: UIImage(named: "Unknown"))
    }
    
    
}
