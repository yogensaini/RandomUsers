//
//  TbCellDetails.swift
//  RandomUsersInfo
//
//  Created by Yogender Saini on 17/01/23.
//

import UIKit

class TbCellDetails: UITableViewCell {

    @IBOutlet weak var lblName : UILabel!
    @IBOutlet weak var lblGender : UILabel!
    @IBOutlet weak var lblCellNo : UILabel!
    @IBOutlet weak var lblEmail : UILabel!
    @IBOutlet weak var lblAddress : UILabel!
    @IBOutlet weak var lblNatinality : UILabel!

    @IBOutlet weak var img : UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func setData(pet : UserDataModel) {
        self.lblName.text = pet.name.title + " " + pet.name.first + " " + pet.name.last
        self.lblGender.text = "Gender : " + pet.gender
        self.lblEmail.text = "Email : " + pet.email
        self.lblCellNo.text = "Cell No : " + pet.cell
        self.lblNatinality.text = "Nationality : " + pet.nat + " citizen"
        let address =  pet.getAddress()
        self.lblAddress.text = "Address : " + address
        self.img.sd_setImage(with: URL(string: pet.picture.large), placeholderImage: UIImage(named: "Unknown"))
    }
    
    
}
