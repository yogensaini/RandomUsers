//
//  UserDataModel.swift
//  UserInfomation
//
//  Created by Yogender Saini on 15/12/22.
//

import UIKit

class userResp: Decodable {
    var results : [UserDataModel]
}

class UserDataModel: Decodable {
    
    var name : UserName
    var picture : UserPicture
    var gender : String
    var email : String
    var cell : String
    var nat : String
    var location :  locationGroup

    func  getFullName() -> String {
        return name.title + " " + name.first + " " + name.last
    }

    func  getAddress() -> String {
        return  String(location.street.number) + ", " + location.street.name + ", " + location.city + ", " + location.state + ", " + location.country 
    }
}

class UserName: Decodable {
    var title :String
    var first :String
    var last :String
}

class UserPicture: Decodable {
    var large :String
    var medium :String
    var thumbnail :String
}

class locationGroup: Decodable {
    var city :String
    var state :String
    var country :String
    var street : street
    var coordinates : coordinates
    var timezone: timezone
}

class street: Decodable {
    var number : Int
    var name :String
}

class coordinates: Decodable {
    var latitude :String
    var longitude :String
}

class timezone: Decodable {
    var offset :String
    var description :String
}
