//
//  DetailsViewController.swift
//  RandomUsersInfo
//
//  Created by Yogender Saini on 17/01/23.
//

import UIKit

class DetailsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    var userDetail : UserDataModel?
    @IBOutlet weak var tbDetails : UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.registerCell()
    }
    
    static func getInstance() -> DetailsViewController {
        let st = UIStoryboard(name: "Main", bundle: nil)
        return st.instantiateViewController(withIdentifier: "DetailsViewController") as! DetailsViewController
    }
    
    func registerCell() {
        let nib = UINib(nibName: "TbCellDetails", bundle: nil)
        self.tbDetails.register(nib, forCellReuseIdentifier: "TbCellDetails")
    }
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TbCellDetails") as! TbCellDetails
        cell.setData(pet: userDetail!)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 500
    }
    
}
