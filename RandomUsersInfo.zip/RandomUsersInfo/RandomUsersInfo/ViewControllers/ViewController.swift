//
//  ViewController.swift
//  RandomUsersInfo
//
//  Created by Yogender Saini on 16/01/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tblList : UITableView!
    let vm = UserDataViewModel()
    var arrUsers = [UserDataModel]()
    var arrFilterUsers = [UserDataModel]()
    private var search = UISearchController(searchResultsController: nil)

    override func viewDidLoad() {
           super.viewDidLoad()
        let vm = UserDataViewModel()
        vm.delegate = self
        vm.getDataFromAPi()
           search.searchBar.delegate = self
           search.searchBar.sizeToFit()
           search.obscuresBackgroundDuringPresentation = false
           search.hidesNavigationBarDuringPresentation = true
           self.definesPresentationContext = true
           search.searchBar.placeholder = "Search here"
           self.navigationItem.searchController = search
        title = "Users"
       }

       override func viewWillAppear(_ animated: Bool) {
           super.viewWillAppear(animated)
           navigationItem.hidesSearchBarWhenScrolling = false
       }

       override func viewWillDisappear(_ animated: Bool) {
           super.viewWillDisappear(animated)
           navigationItem.hidesSearchBarWhenScrolling = true
       }
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrFilterUsers.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TbCellUserInfo") as! TbCellUserInfo
        cell.setData(pet: self.arrFilterUsers[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = DetailsViewController.getInstance()
        vc.userDetail = self.arrFilterUsers[indexPath.row]
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
extension ViewController : UISearchBarDelegate {
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        debugPrint("searchBarCancelButtonClicked")
        self.arrFilterUsers = self.arrUsers
        self.tblList.reloadData()
    }
    
    func searchBar(_ searchBar: UISearchBar, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {

        let newCharLength = (searchBar.text ?? "").count + text.count - range.length
        debugPrint(newCharLength)

        DispatchQueue.main.asyncAfter(deadline: .now()+1) {
            self.showSerachtext(st: searchBar.text!)
        
        var arrSearchUsers = [UserDataModel]()
        let searchUsers = self.arrUsers
            if newCharLength > 0 {
                
                arrSearchUsers = searchUsers.filter({ obj in
                    let txx = searchBar.text!
                    return (obj.name.first.lowercased().contains((txx.lowercased())))
                })
                self.arrFilterUsers = arrSearchUsers
                self.tblList.reloadData()
            } else {
                self.arrFilterUsers = searchUsers
                self.tblList.reloadData()
            }
        }
        return true
    }
    
    func showSerachtext(st : String) {
        debugPrint(st)
    }
    
}
extension ViewController : userDataProtocol {
    func getUserDataDelegate(arrUserData: [UserDataModel]) {
        
        self.arrUsers = arrUserData
        self.arrFilterUsers = arrUserData
        if self.arrUsers.count >= 1 {
            
            DispatchQueue.main.async {
            let nib = UINib(nibName: "TbCellUserInfo", bundle: nil)
            self.tblList.register(nib, forCellReuseIdentifier: "TbCellUserInfo")
            self.tblList.dataSource = self
            self.tblList.delegate  = self
            self.tblList.reloadData()
            self.tblList.isHidden = false
        }
        } else {
            self.tblList.isHidden = true
            vm.showAlert(errString: "No record to show", vc: self)
        }
    }
    
    
    @IBAction func btnFilterAction(_sender: AnyObject) {

        let alert = UIAlertController(title: "Gender", message: "", preferredStyle: .actionSheet)
        
        alert.addAction(UIAlertAction(title: "Male", style: .destructive , handler:{ (UIAlertAction)in
            self.arrFilterUsers = self.vm.filterGender(filterKey: "1", arrUsers: self.arrUsers)
            self.tblList.reloadData()

        }))

        alert.addAction(UIAlertAction(title: "Female", style: .destructive , handler:{ (UIAlertAction)in
            self.arrFilterUsers = self.vm.filterGender(filterKey: "0", arrUsers: self.arrUsers)
            self.tblList.reloadData()

        }))
        
        alert.addAction(UIAlertAction(title: "All", style: .default , handler:{ (UIAlertAction)in
            self.arrFilterUsers = self.vm.filterGender(filterKey: "2", arrUsers: self.arrUsers)
            self.tblList.reloadData()

        }))

        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler:{ (UIAlertAction)in
        }))

        self.present(alert, animated: true, completion: {
            print("completion block")
        })
    }
}
