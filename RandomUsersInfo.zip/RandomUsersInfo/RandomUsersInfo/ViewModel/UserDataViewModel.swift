//
//  UserDataViewModel.swift
//  UserInfomation
//
//  Created by Yogender Saini on 15/12/22.
//

import UIKit


protocol userDataProtocol {
    func getUserDataDelegate(arrUserData : [UserDataModel])
}

class UserDataViewModel: NSObject {

    let httpRequest = HttpRequest()
    var delegate : userDataProtocol?
    
    func getDataFromAPi() {
        httpRequest.apiRequest { arrUserData in
            debugPrint(arrUserData.count)
            self.delegate?.getUserDataDelegate(arrUserData: arrUserData)
        } complitionFail: { erSting in
            debugPrint(erSting)
        }

    }
    
    func filterGender(filterKey : String, arrUsers : [UserDataModel]) -> [UserDataModel] {
        var arrFiltered : [UserDataModel]
        if filterKey == "0" {
            arrFiltered = arrUsers.filter({ obj in
                return obj.gender == "female"
            })
        } else if filterKey == "1" {
            arrFiltered = arrUsers.filter({ obj in
                return obj.gender == "male"
            })
        } else {
            arrFiltered = arrUsers
        }
        return arrFiltered
    }
    
    func showAlert(errString : String, vc : UIViewController) {
        let alert = UIAlertController(title: "Oops", message: errString, preferredStyle: UIAlertController.Style.alert)

        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
        }))

        vc.present(alert, animated: true, completion: nil)
        
    }
}
